# Tornado BT2 Cockpit Converter & SVGA Technical Dossier

This directory contains the cockpit image conversion utility `bt2_converter.py` and the complete technical reference dossier for the 800x600 SVGA modernization of **Digital Integration's Tornado & Operation Desert Storm**.

---

## 1. Overview of the BT2 Format

In DI Tornado, cockpit panels, canopy frames, and 2D overlays are stored as uncompressed raw raster buffers with the `.BT2` file extension:

* **Pixel Format**: Raw 8-bit linear byte stream (1 byte per pixel).
* **Color Depth**: 256-color indexed palette mapped directly to the Tornado VGA DAC hardware registers (`VISUAL/PALETTES.ASM`).
* **Resolution**:
  * **SVGA Modernization (800x600)**: All active in-flight cockpit panels are standardized to a full-screen **800 x 600** resolution (**480,000 bytes** each).
  * **Review Mode Backdrop (`PREVIEW.BT2`)**: Maintained in its authentic **320 x 200** format (**64,000 bytes**), dynamically hardware-scaled by the SVGA rendering engine to the bottom 800x120 viewport.

### Standard Cockpit Files
| Filename | Resolution | File Size | Description |
| :--- | :--- | :--- | :--- |
| `PILOTPAN.BT2` | 800 x 600 | 480,000 bytes | Front Pilot Cockpit (HUD frame, primary instruments, MFD) |
| `NAVIGPAN.BT2` | 800 x 600 | 480,000 bytes | Navigator / WSO Tactical Console (Radar, Map, TIALD, TABs) |
| `PSIDEPAN.BT2` | 800 x 600 | 480,000 bytes | Pilot Left / Right Auxiliary Side Consoles |
| `NSIDEPAN.BT2` | 800 x 600 | 480,000 bytes | Navigator Left / Right Auxiliary Side Consoles |
| `FRAMEPAN.BT2` | 800 x 600 | 480,000 bytes | Canopy Arch, Mirrors, and Cockpit Structural Ironwork |
| `EXTRAPAN.BT2` | 800 x 600 | 480,000 bytes | Look-Down Center Cockpit & Warning Annunciators |
| `PREVIEW.BT2`  | 320 x 200 | 64,000 bytes  | Mission Debriefing & Aircraft Review Console Backdrop |

---

## 2. Using `bt2_converter.py`

`bt2_converter.py` is a self-contained Python 3 utility for bidirectional conversion between raw `.BT2` binary buffers and editable `.PNG` images. It embeds the exact 256-color canonical Tornado VGA DAC palette, ensuring 100% palette-indexed roundtrip fidelity.

### Requirements
* **Python 3.7+**
* **Pillow (PIL)**: `pip install Pillow`

### Command-Line Usage

#### Exporting a Single Cockpit to PNG
Converts an existing `.BT2` buffer into an 8-bit indexed PNG:
```bash
python bt2_converter.py export PILOTPAN.BT2 PILOTPAN.png
```
*(If the output filename is omitted, `PILOTPAN.png` is created automatically).*

#### Importing an Edited PNG back to BT2
Converts an edited PNG image back into the binary `.BT2` format:
```bash
python bt2_converter.py import PILOTPAN.png PILOTPAN.BT2
```

#### Batch Export
Converts all `.BT2` files in a folder into PNG format:
```bash
# Export all cockpit files from the game folder (parent directory) into ./exported_png/
python bt2_converter.py export-all .. ./exported_png
```

#### Batch Import
Converts all edited PNGs in a folder back into `.BT2` binary files:
```bash
# Import all PNGs from ./exported_png/ back to the game folder (parent directory)
python bt2_converter.py import-all ./exported_png ..
```

### Image Editing Best Practices
* **Indexed Color Editing (Recommended)**: For maximum precision, open the exported PNG in an editor that supports indexed 8-bit color mode (such as **GIMP**, **Photoshop**, or **Aseprite**). Editing within the established 256-color palette ensures pixel-perfect reproduction without color quantisation artifacts.
* **TrueColor (RGB/RGBA) Editing**: If you save your edits in 24-bit RGB or 32-bit RGBA mode, `bt2_converter.py` automatically computes the closest Euclidean RGB distance to the canonical 256-color palette for each pixel upon import.

---

## 3. Technical Dossier: SVGA (800x600) Instrument Layout

This section details the geometric coordinate system, scaling formulas, and exact screen coordinates of all cockpit avionics, needles, digital readouts, and Multi-Function Displays (MFDs) in the SVGA engine.

### Geometric Scaling Model
* **Base Game Resolution**: 320 x 200 pixels
* **SVGA Target Resolution**: 800 x 600 pixels
* **Vertical Layout Partition**:
  * **Forward Sky / HUD Viewing Aperture**: $Y = 0 \dots 99$ (Height = 100 px)
  * **Instrument Panel Surface**: $Y = 100 \dots 599$ (Height = 500 px, Width = 800 px)
* **Scale Factors**:
  * Horizontal Scale Factor ($S_x$): $\frac{800}{320} = 2.5\times$
  * Vertical Panel Scale Factor ($S_y$): $\frac{500}{200} = 2.5\times$
* **Coordinate Transformations**:
  $$\begin{aligned}
  X_{\text{SVGA}} &= \text{round}(X_{\text{VGA}} \times 2.5) \\
  Y_{\text{SVGA}} &= \text{round}(100 + (Y_{\text{VGA}} \times 2.5)) \\
  W_{\text{SVGA}} &= \text{round}(W_{\text{VGA}} \times 2.5) \\
  H_{\text{SVGA}} &= \text{round}(H_{\text{VGA}} \times 2.5) \\
  R_{\text{SVGA}} &= \text{round}(R_{\text{VGA}} \times 2.5) \quad \text{(Gauge Needle Radius)}
  \end{aligned}$$

---

### Pilot Front Instrument Panel (`PILOTPAN.BT2`)
* **VGA Source Extent**: $320 \times 104$ pixels ($Y = 96 \dots 199$)
* **SVGA Render Extent**: $800 \times 260$ pixels ($Y = 340 \dots 599$)

| Instrument / Gauge | VGA Coordinates $(X, Y)$ | VGA Size / Radius | SVGA Coordinates $(X, Y)$ | SVGA Size / Radius | Notes / Subsystems |
| :--- | :---: | :---: | :---: | :---: | :--- |
| **HUD Box (`UpdateHUD`)** | 32, 0 | 256 x 96 | **80, 0** | **640 x 240** | Vectorial HUD viewing window |
| **Attitude Director (`UpdateADI`)** | 92, 150 | $R = 18$ | **230, 475** | **$R = 45$** | Primary artificial horizon |
| `DrawADIRollBug` (Roll Pointer) | 92, 150 | - | **230, 475** | - | ADI sky roll pointer |
| **Horizontal Situation (`UpdateHSI`)** | 95, 184 | $R = 18$ | **238, 560** | **$R = 45$** | Compass rose & navigation course |
| `LOCAL_X`, `LOCAL_Y` | 95, 184 | - | **238, 560** | - | ILS localiser needle origin |
| `GLIDE_X`, `GLIDE_Y` | 78, 186 | - | **195, 565** | - | ILS glide slope deviation needle |
| **Airspeed Indicator (`UpdateSpeed`)** | 53, 155 | $R = 14$ | **133, 488** | **$R = 35$** | Calibrated airspeed gauge |
| Digital Mach Readout | 48, 156 | - | **120, 490** | - | Digital Mach number text |
| **Barometric Altimeter (`UpdateAltimeter`)** | 53, 185 | $R = 14$ | **133, 563** | **$R = 35$** | Barometric altitude pointer |
| Digital Baro Altitude Window | 44, 186 | - | **110, 565** | - | 3-digit rolling drum display |
| **Radar Altimeter (`UpdateRadAlt`)** | 49, 127 | $R = 14$ | **123, 418** | **$R = 35$** | Low-altitude radar height dial |
| **Vertical Speed Ind (`UpdateVSI`)** | 19, 153 | $R = 14$ | **48, 483** | **$R = 35$** | Rate-of-climb indicator |
| **Accelerometer / G-Meter (`UpdateGMeter`)** | 285, 125 | $R = 12$ | **713, 413** | **$R = 30$** | G-load indicator needle |
| **Standby Compass (`UpdateCompass`)** | 308, 146 | - | **770, 465** | - | Magnetic standby compass readout |
| **Oxygen Flow Dolly (`UpdateOxyDolly`)** | 308, 187 | 10 x 8 | **770, 568** | **25 x 20** | Oxygen blinking flow doll's eye |
| **Fuel Totalizer (`UpdateFuel`)** | 276, 195 | - | **690, 588** | - | 5-digit digital fuel weight |
| LH Engine Fuel Flow Needle | 285, 152 | $R = 10$ | **713, 480** | **$R = 25$** | Left engine fuel consumption |
| RH Engine Fuel Flow Needle | 285, 180 | $R = 10$ | **713, 550** | **$R = 25$** | Right engine fuel consumption |
| **Engine RPM Gauges (`UpdateEngRPM`)** | | | | | |
| LH Engine RPM Needle | 221, 152 | $R = 10$ | **553, 480** | **$R = 25$** | Left spool RPM percentage |
| RH Engine RPM Needle | 253, 152 | $R = 10$ | **633, 480** | **$R = 25$** | Right spool RPM percentage |
| Digital RPM Readouts (LH / RH) | 216, 155 / 248, 155 | - | **540, 488 / 620, 488** | - | Digital RPM numeric readouts |
| **Turbine Gas Temp (`UpdateEngTemp`)** | | | | | |
| LH Engine TGT Needle | 221, 180 | $R = 10$ | **553, 550** | **$R = 25$** | Left turbine temperature |
| RH Engine TGT Needle | 253, 180 | $R = 10$ | **633, 550** | **$R = 25$** | Right turbine temperature |
| **Flight Control Surfaces (`UpdateCtrlSFace`)** | | | | | |
| Flaps Deployment Indicator | 11, 170 | - | **28, 525** | - | Trailing-edge flaps indicator |
| Slats Deployment Indicator | 22, 170 | - | **55, 525** | - | Leading-edge slats indicator |
| Wing Sweep Angle Indicator | 26, 178 | - | **65, 545** | - | Variable sweep wing position |
| Airbrakes Indicator | 11, 180 | - | **28, 550** | - | Airbrake deployment flags |
| **E-Scope Radar (`UpdateEScope`)** | 72, 111 | 32 x 20 | **180, 378** | **80 x 50** | Terrain Following Radar (TFR) |
| E-Scope Datum Line | 6 | - | **15** | - | Radar elevation reference line |
| **Radar Warning (`UpdateRWR`)** | 236, 121 | $R = 12$ | **590, 403** | **$R = 30$** | RWR azimuth display circle |
| RWR Redraw Region | 216, 109 | 48 x 24 | **540, 324** | **120 x 84** | Full refresh window (expanded in v1.2) |
| **Center Pilot MFD (`UpdatePilotMFD`)** | 120, 144 | 80 x 56 | **300, 460** | **200 x 140** | Projected map & tactical display |

---

### Navigator / WSO Tactical Console (`NAVIGPAN.BT2`)
* **VGA Source Extent**: $320 \times 200$ pixels ($Y = 0 \dots 199$)
* **SVGA Render Extent**: $800 \times 500$ pixels ($Y = 100 \dots 599$)

| Instrument / Subsystem | VGA Coordinates $(X, Y)$ | VGA Size / Radius | SVGA Coordinates $(X, Y)$ | SVGA Size / Radius | Description |
| :--- | :---: | :---: | :---: | :---: | :--- |
| **Nav ADI (`UpdateADI`)** | 84, 150 | $R = 14$ | **210, 475** | **$R = 35$** | Navigator backup horizon |
| **Nav HSI (`UpdateHSI`)** | 87, 184 | $R = 14$ | **218, 560** | **$R = 35$** | Navigator compass rose |
| `LOCAL_X`, `LOCAL_Y` | 87, 184 | - | **218, 560** | - | Localiser course deviation |
| `GLIDE_X`, `GLIDE_Y` | 70, 186 | - | **175, 565** | - | Glide slope needle |
| **Nav Altimeter (`UpdateAltimeter`)** | 141, 25 | $R = 10$ | **353, 163** | **$R = 25$** | Upper repeater altimeter |
| **Nav Airspeed (`UpdateSpeed`)** | 177, 25 | $R = 10$ | **443, 163** | **$R = 25$** | Upper repeater airspeed |
| **Mechanical Flight Clock (`UpdateClock`)** | 37, 173 | $R = 14$ | **93, 533** | **$R = 35$** | Mission chronometer |
| **Stores Display (`UpdateStores` / SDISP)** | 128, 148 | 64 x 47 | **320, 470** | **160 x 118** | Weapon station status screen |
| **Nav MFD 1 (Left TV - Radar)** | 16, 24 | 96 x 96 | **40, 160** | **240 x 240** | Air-to-ground / Air-to-air radar |
| **Nav MFD 2 (Center - Moving Map)** | 120, 56 | 80 x 64 | **300, 240** | **200 x 160** | Tactical digital moving map |
| **Nav MFD 3 (Right TV - TIALD)** | 208, 24 | 96 x 96 | **520, 160** | **240 x 240** | FLIR / TV / Laser tracker |
| **Tactical Board 1 (`UpdateTAB1`)** | 16, 120 | 96 x 20 | **40, 400** | **240 x 50** | Left system alphanumeric board |
| **Tactical Board 2 (`UpdateTAB2`)** | 208, 120 | 96 x 20 | **520, 400** | **240 x 50** | Right system alphanumeric board |

---

### Tornado ADV Variant Overlays (`VGAPANEL.ASM`)
The Tornado F.3 / ADV (Air Defence Variant) reuses base cockpit artwork with dynamic assembly sub-sprite blits:

| Feature | VGA Source $(X, Y, W, H)$ | VGA Dest $(X, Y)$ | SVGA Dest $(X, Y, W, H)$ | Notes |
| :--- | :---: | :---: | :---: | :--- |
| **Pilot Weapon Status Panel** | `NAVIGPAN(128, 149, 64, 45)` | 56, 96 | **140, 340 (160 x 113)** | Blitted into pilot cockpit |
| **Late Arming Switch Animation** | `NAVIGPAN(128, 94, 64, 11)` | 208, 87 | **520, 318 (160 x 28)** | Weapon arming switch |

---

### External View Flight Telemetry Bar (`EXTRNPAN.ASM`)
When switching to external chase camera or tracking views, flight telemetry is rendered along the lower border:

| Telemetry Element | VGA $(X, Y)$ | VGA Size | SVGA $(X, Y)$ | SVGA Size | Description |
| :--- | :---: | :---: | :---: | :---: | :--- |
| **Status Bar Backdrop** | 0, 190 | 320 x 10 | **0, 580** | **800 x 20** | Dark background strip |
| **Base Telemetry String** | 0, 190 | - | **240, 588** | - | `"SPEED=  KTS HDG=  ALT= ..."` |
| Airspeed Readout (`Vkts`) | 24, 190 | - | **264, 588** | - | 4-digit indicated airspeed |
| Heading Readout (`DispHdg`) | 72, 190 | - | **312, 588** | - | 3-digit heading + degree symbol |
| Altitude Readout (`AltValPtr`) | 108, 190 | - | **348, 588** | - | Barometric or radar altitude |
| Vertical Speed (`VSIVal`) | 156, 190 | - | **396, 588** | - | 5-digit climb/dive rate |
| Fuel Remaining (`FuelWt`) | 228, 190 | - | **468, 588** | - | 5-digit total internal fuel |
| Camera Mode Label | 284, 190 | - | **524, 588** | - | `"TRACKING"`, `"SATELLITE"`, etc. |
