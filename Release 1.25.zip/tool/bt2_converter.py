#!/usr/bin/env python3
"""
Tornado BT2 / Cockpit Bitmap Converter
Converts Tornado .BT2 cockpit bitmaps to/from editable PNG format with canonical 256-color palette.
Supports both 800x600 SVGA and 320x200 VGA formats, with exact 8-bit palette-indexed roundtrip.
"""

import os
import sys
import re
from PIL import Image

# Canonical 256-color VGA DAC RGB palette from Tornado (VISUAL/PALETTES.ASM)
CANONICAL_VGA_PALETTE = [(0, 0, 0),
 (255, 85, 85),
 (255, 255, 85),
 (85, 255, 255),
 (255, 255, 255),
 (0, 105, 170),
 (130, 178, 231),
 (255, 142, 20),
 (255, 255, 255),
 (207, 207, 207),
 (162, 162, 162),
 (113, 113, 113),
 (69, 69, 69),
 (255, 65, 81),
 (203, 12, 28),
 (166, 0, 0),
 (65, 105, 162),
 (36, 65, 101),
 (255, 235, 150),
 (255, 186, 0),
 (255, 150, 0),
 (81, 255, 134),
 (255, 207, 207),
 (207, 207, 255),
 (255, 255, 255),
 (203, 203, 203),
 (150, 150, 150),
 (125, 125, 125),
 (97, 97, 97),
 (0, 0, 0),
 (142, 166, 166),
 (130, 158, 158),
 (121, 150, 150),
 (109, 142, 142),
 (101, 134, 134),
 (93, 125, 125),
 (227, 190, 134),
 (199, 162, 113),
 (174, 138, 93),
 (146, 109, 77),
 (121, 89, 60),
 (190, 138, 113),
 (182, 125, 101),
 (178, 117, 89),
 (174, 105, 81),
 (170, 97, 73),
 (227, 227, 227),
 (174, 174, 174),
 (77, 77, 77),
 (48, 48, 48),
 (251, 255, 0),
 (255, 223, 0),
 (255, 186, 0),
 (255, 154, 0),
 (255, 130, 0),
 (255, 97, 0),
 (0, 203, 138),
 (0, 186, 121),
 (0, 166, 113),
 (0, 134, 101),
 (0, 203, 199),
 (0, 178, 174),
 (0, 162, 154),
 (0, 150, 142),
 (113, 150, 113),
 (101, 138, 101),
 (89, 125, 89),
 (81, 117, 81),
 (73, 105, 69),
 (65, 97, 60),
 (247, 247, 247),
 (65, 73, 97),
 (0, 0, 16),
 (138, 138, 138),
 (109, 109, 109),
 (0, 150, 101),
 (121, 150, 142),
 (101, 101, 101),
 (85, 93, 93),
 (0, 121, 117),
 (0, 154, 101),
 (8, 158, 105),
 (20, 162, 109),
 (60, 166, 113),
 (85, 170, 113),
 (101, 174, 113),
 (113, 178, 109),
 (130, 178, 105),
 (142, 178, 101),
 (154, 178, 97),
 (162, 178, 97),
 (170, 178, 93),
 (178, 178, 93),
 (186, 174, 93),
 (195, 170, 93),
 (203, 166, 93),
 (255, 255, 255),
 (239, 247, 255),
 (223, 239, 255),
 (211, 235, 255),
 (199, 227, 255),
 (182, 223, 255),
 (170, 215, 255),
 (154, 207, 255),
 (142, 203, 255),
 (125, 195, 255),
 (113, 190, 255),
 (97, 182, 255),
 (85, 174, 255),
 (73, 170, 255),
 (56, 162, 255),
 (44, 158, 255),
 (44, 138, 56),
 (44, 142, 48),
 (52, 150, 44),
 (65, 158, 48),
 (77, 162, 48),
 (89, 170, 52),
 (105, 178, 52),
 (121, 182, 52),
 (138, 190, 56),
 (154, 199, 56),
 (174, 203, 56),
 (190, 211, 60),
 (211, 219, 60),
 (223, 215, 60),
 (231, 207, 60),
 (239, 199, 65),
 (162, 162, 174),
 (113, 113, 130),
 (170, 20, 20),
 (121, 121, 134),
 (44, 44, 60),
 (36, 235, 69),
 (255, 138, 32),
 (113, 113, 134),
 (227, 235, 239),
 (0, 0, 0),
 (174, 174, 174),
 (40, 77, 138),
 (150, 0, 0),
 (182, 28, 0),
 (0, 195, 0),
 (0, 219, 0),
 (44, 138, 56),
 (130, 81, 40),
 (77, 77, 77),
 (32, 60, 158),
 (0, 178, 174),
 (0, 134, 101),
 (0, 186, 121),
 (0, 0, 0),
 (255, 85, 85),
 (178, 178, 178),
 (170, 85, 0),
 (0, 0, 0),
 (255, 85, 85),
 (178, 178, 178),
 (251, 142, 20),
 (207, 40, 0),
 (0, 36, 4),
 (0, 48, 0),
 (0, 60, 0),
 (0, 73, 0),
 (0, 85, 0),
 (0, 97, 0),
 (0, 109, 0),
 (0, 121, 0),
 (0, 134, 0),
 (0, 146, 0),
 (0, 158, 0),
 (0, 170, 0),
 (0, 182, 0),
 (0, 195, 0),
 (0, 207, 0),
 (0, 219, 0),
 (219, 239, 231),
 (199, 227, 219),
 (182, 219, 207),
 (162, 207, 199),
 (150, 199, 190),
 (134, 186, 182),
 (117, 178, 174),
 (105, 166, 166),
 (89, 154, 158),
 (77, 138, 146),
 (69, 121, 138),
 (56, 109, 125),
 (48, 97, 117),
 (36, 81, 109),
 (28, 69, 97),
 (24, 56, 89),
 (0, 0, 8),
 (12, 12, 24),
 (20, 20, 32),
 (28, 28, 44),
 (36, 36, 52),
 (44, 44, 60),
 (52, 52, 69),
 (60, 60, 77),
 (69, 69, 85),
 (77, 77, 93),
 (85, 85, 101),
 (93, 93, 109),
 (105, 105, 121),
 (113, 113, 130),
 (121, 121, 138),
 (130, 130, 146),
 (138, 138, 154),
 (146, 146, 162),
 (154, 154, 170),
 (162, 162, 174),
 (170, 170, 182),
 (178, 178, 190),
 (186, 186, 199),
 (195, 195, 211),
 (203, 203, 219),
 (211, 211, 227),
 (219, 219, 231),
 (227, 227, 239),
 (235, 235, 247),
 (36, 0, 0),
 (65, 4, 4),
 (113, 28, 28),
 (146, 12, 12),
 (170, 20, 20),
 (207, 36, 28),
 (227, 36, 36),
 (255, 48, 28),
 (0, 28, 0),
 (44, 44, 60),
 (52, 52, 73),
 (65, 65, 85),
 (77, 77, 97),
 (85, 85, 101),
 (154, 154, 170),
 (186, 186, 199),
 (219, 138, 0),
 (255, 162, 20),
 (207, 130, 0),
 (219, 138, 0),
 (73, 40, 0),
 (101, 56, 4),
 (158, 109, 0),
 (174, 113, 0),
 (0, 121, 0),
 (231, 154, 0),
 (85, 4, 4),
 (255, 162, 20),
 (142, 125, 109),
 (125, 113, 113),
 (150, 125, 130),
 (158, 138, 121),
 (121, 105, 89),
 (255, 85, 255),
 (203, 203, 219)]

def get_palette():
    """Returns flat palette list [r0, g0, b0, ...] and list of RGB tuples."""
    rgb_tuples = CANONICAL_VGA_PALETTE
    flat_palette = []
    for r, g, b in rgb_tuples:
        flat_palette.extend([r, g, b])
    return flat_palette, rgb_tuples

# Known cockpit file specifications
COCKPIT_FILES = [
    "PILOTPAN.BT2",
    "NAVIGPAN.BT2",
    "PSIDEPAN.BT2",
    "NSIDEPAN.BT2",
    "FRAMEPAN.BT2",
    "EXTRAPAN.BT2",
    "PREVIEW.BT2",
]

def infer_dimensions(file_size):
    """Infers (width, height) based on standard file size."""
    if file_size == 480000:
        return 800, 600  # SVGA full panel
    elif file_size == 64000:
        return 320, 200  # Standard VGA / PREVIEW.BT2
    elif file_size == 33280:
        return 320, 104  # Original VGA PILOTPAN
    elif file_size == 12800:
        return 320, 40   # Original VGA PSIDEPAN / NSIDEPAN
    elif file_size == 5120:
        return 320, 16   # Original VGA FRAMEPAN
    else:
        # Default fallback
        if file_size % 800 == 0:
            return 800, file_size // 800
        elif file_size % 320 == 0:
            return 320, file_size // 320
        return 800, 600

def bt2_to_png(bt2_path, png_path, width=None, height=None):
    """Converts a .BT2 linear indexed file to an 8-bit indexed PNG."""
    with open(bt2_path, "rb") as f:
        data = f.read()

    file_size = len(data)
    if width is None or height is None:
        width, height = infer_dimensions(file_size)

    expected = width * height
    if len(data) != expected:
        print(f"Warning: {bt2_path} is {len(data)} bytes, expected {expected} for {width}x{height}")
        if len(data) < expected:
            data = data + b"\x00" * (expected - len(data))
        else:
            data = data[:expected]

    flat_palette, _ = get_palette()
    img = Image.frombytes("P", (width, height), data)
    img.putpalette(flat_palette)
    img.save(png_path)
    print(f"Exported: {bt2_path} ({width}x{height}, {file_size} B) -> {png_path}")

def png_to_bt2(png_path, bt2_path, width=None, height=None):
    """Converts a PNG image back to a raw .BT2 binary file."""
    img = Image.open(png_path)
    if width is not None and height is not None:
        if img.size != (width, height):
            img = img.resize((width, height), Image.NEAREST)
    else:
        width, height = img.size

    flat_palette, rgb_tuples = get_palette()

    if img.mode == "P":
        # Check if palette matches or extract direct indexed bytes
        out_bytes = img.tobytes()
    else:
        # Convert RGB/RGBA to closest canonical palette index
        img_rgb = img.convert("RGB")
        color_map = {}
        for idx, rgb in enumerate(rgb_tuples):
            if rgb not in color_map:
                color_map[rgb] = idx

        pixels = img_rgb.load()
        out_bytes = bytearray(width * height)
        out_idx = 0

        for y in range(height):
            for x in range(width):
                c = pixels[x, y]
                if c in color_map:
                    out_bytes[out_idx] = color_map[c]
                else:
                    best_idx = 0
                    best_dist = 999999999
                    for p_idx, prgb in enumerate(rgb_tuples):
                        dr = c[0] - prgb[0]
                        dg = c[1] - prgb[1]
                        db = c[2] - prgb[2]
                        dist = dr * dr + dg * dg + db * db
                        if dist < best_dist:
                            best_dist = dist
                            best_idx = p_idx
                            if dist == 0:
                                break
                    color_map[c] = best_idx
                    out_bytes[out_idx] = best_idx
                out_idx += 1

    with open(bt2_path, "wb") as f:
        f.write(out_bytes)
    print(f"Imported: {png_path} ({width}x{height}) -> {bt2_path} ({len(out_bytes)} B)")

def export_all(in_dir=".", out_dir="./exported_png"):
    """Batch exports all BT2 files found in in_dir."""
    os.makedirs(out_dir, exist_ok=True)
    found = 0
    for fname in os.listdir(in_dir):
        if fname.upper().endswith(".BT2"):
            in_file = os.path.join(in_dir, fname)
            out_file = os.path.join(out_dir, os.path.splitext(fname)[0] + ".png")
            bt2_to_png(in_file, out_file)
            found += 1
    if found == 0:
        print(f"No .BT2 files found in directory: {in_dir}")
    else:
        print(f"Successfully exported {found} files to: {out_dir}")

def import_all(in_dir="./exported_png", out_dir="."):
    """Batch imports all PNG files matching cockpit names back to BT2."""
    os.makedirs(out_dir, exist_ok=True)
    found = 0
    for fname in os.listdir(in_dir):
        if fname.lower().endswith(".png"):
            base = os.path.splitext(fname)[0].upper()
            target_bt2 = base + ".BT2"
            in_file = os.path.join(in_dir, fname)
            out_file = os.path.join(out_dir, target_bt2)
            png_to_bt2(in_file, out_file)
            found += 1
    if found == 0:
        print(f"No .png files found in directory: {in_dir}")
    else:
        print(f"Successfully imported {found} files to: {out_dir}")

def print_help():
    print("""
================================================================================
Tornado BT2 / Cockpit Bitmap Converter (Release 1.2 Tool Suite)
================================================================================
Usage:
  python bt2_converter.py export <input.bt2> [output.png]
  python bt2_converter.py import <input.png> [output.bt2]
  python bt2_converter.py export-all [input_dir] [output_dir]
  python bt2_converter.py import-all [input_dir] [output_dir]

Examples:
  # Export single SVGA cockpit panel to indexed PNG
  python bt2_converter.py export PILOTPAN.BT2 PILOTPAN.png

  # Import edited PNG back to raw BT2 buffer
  python bt2_converter.py import PILOTPAN.png PILOTPAN.BT2

  # Batch export all .BT2 files in parent directory to ./exported_png
  python bt2_converter.py export-all .. ./exported_png

  # Batch import all edited .png files back to parent directory
  python bt2_converter.py import-all ./exported_png ..
================================================================================
""")

if __name__ == "__main__":
    args = sys.argv[1:]
    if not args or args[0] in ("-h", "--help", "help"):
        print_help()
        sys.exit(0)

    cmd = args[0].lower()
    if cmd == "export":
        if len(args) < 2:
            print("Error: export requires at least an input .BT2 file.")
            sys.exit(1)
        in_bt2 = args[1]
        out_png = args[2] if len(args) > 2 else os.path.splitext(in_bt2)[0] + ".png"
        bt2_to_png(in_bt2, out_png)
    elif cmd == "import":
        if len(args) < 2:
            print("Error: import requires at least an input .png file.")
            sys.exit(1)
        in_png = args[1]
        out_bt2 = args[2] if len(args) > 2 else os.path.splitext(in_png)[0] + ".BT2"
        png_to_bt2(in_png, out_bt2)
    elif cmd in ("export-all", "export_all"):
        in_d = args[1] if len(args) > 1 else "."
        out_d = args[2] if len(args) > 2 else "./exported_png"
        export_all(in_d, out_d)
    elif cmd in ("import-all", "import_all"):
        in_d = args[1] if len(args) > 1 else "./exported_png"
        out_d = args[2] if len(args) > 2 else "."
        import_all(in_d, out_d)
    else:
        print(f"Unknown command: '{cmd}'")
        print_help()
        sys.exit(1)
