#!/usr/bin/env python3
"""
scale_bt2_800x600.py - Tornado SVGA Cockpit Scaler & Extrapolator (800x600)

1. Extrapolates 320x200 cockpit .BT2 images to 800x600 (2.5x horizontally, 3.0x vertically).
2. Preserves exact 8-bit palette indices with Nearest Neighbor resampling (mode 'P').
3. Pre-composites HUD brackets onto PILOTPAN lines 0..287 while preserving all hidden
   sprite atlas areas behind the MFD (Y=432..570) and on NAVIGPAN (Y=78..250).
4. Pre-composites the complete LookDown cockpit into EXTRAPAN.BT2 (reflected kneepads,
   asymmetrical details, and straps).
5. Pre-composites the complete canopy frame and ironwork struts into FRAMEPAN.BT2.
6. Extrapolates all sub-sprite coordinates and outputs scaled metadata JSON.
7. Generates uncompressed 800x600 .BT2 binary files (480,000 bytes each) and deploys them.
"""

import os
import sys
import json
import shutil
from PIL import Image

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if os.path.basename(SCRIPT_DIR).upper() == "TOOLS":
    PROJECT_ROOT = os.path.dirname(SCRIPT_DIR)
else:
    PROJECT_ROOT = SCRIPT_DIR

ORIG_EXTRACTED_DIR = os.path.join(PROJECT_ROOT, "2D GRAPHICS ORIGINAL", "extracted_bt2")
OUT_800_DIR = os.path.join(PROJECT_ROOT, "2D GRAPHICS ORIGINAL", "extracted_800x600")
BIN_FLIGHT_DIR = os.path.join(os.path.dirname(PROJECT_ROOT), "Desert Storm bin", "TORNADO.CD", "FLIGHT")
SRC_FLIGHT_DIR = os.path.join(PROJECT_ROOT, "TORNADO", "FLIGHT")

CANVAS_W = 800
CANVAS_H = 600
SCALE_X = 2.5
SCALE_Y = 3.0


def scale_rect(rect):
    """Scales [x, y, w, h] by (2.5, 3.0)."""
    x, y, w, h = rect
    return [
        int(round(x * SCALE_X)),
        int(round(y * SCALE_Y)),
        int(round(w * SCALE_X)),
        int(round(h * SCALE_Y))
    ]


def scale_point(pt):
    """Scales [x, y] by (2.5, 3.0)."""
    x, y = pt
    return [
        int(round(x * SCALE_X)),
        int(round(y * SCALE_Y))
    ]


def process_all():
    os.makedirs(OUT_800_DIR, exist_ok=True)
    print(f"Extrapolating 320x200 cockpits to 800x600 in: {OUT_800_DIR}")

    # Panels to process
    panels = ["PILOTPAN", "NAVIGPAN", "EXTRAPAN", "FRAMEPAN", "PSIDEPAN", "NSIDEPAN", "PREVIEW"]

    # 1. Process EXTRAPAN first to obtain sprites needed for composites
    extra_dir = os.path.join(ORIG_EXTRACTED_DIR, "EXTRAPAN")
    extra_png = os.path.join(extra_dir, "EXTRAPAN.png")
    if not os.path.exists(extra_png):
        raise FileNotFoundError(f"Missing {extra_png}. Run bt2toIMG.py first.")

    extra_img = Image.open(extra_png)
    pal = extra_img.getpalette()
    extra_pixels = extra_img.load()

    # Build 320x200 composite of HUD brackets from EXTRAPAN
    # (Matches original VGA_Brackets rectangle list in VGAPANEL.ASM:1857-1873)
    b_rects = [
        (160, 84, 56, 10, 16, 11),
        (168, 95, 64, 21, 8, 75),
        (200, 84, 96, 10, 8, 63),
        (200, 147, 96, 73, 16, 23),
        (160, 171, 56, 0, 8, 10),
        (192, 171, 88, 0, 24, 10),
        (176, 84, 72, 10, 24, 86),
        (168, 171, 64, 0, 24, 10),
        (224, 84, 216, 10, 8, 63),
        (216, 147, 208, 73, 16, 23),
        (256, 84, 248, 10, 16, 36),
        (248, 120, 240, 46, 8, 50),
        (160, 182, 208, 0, 24, 10),
        (208, 182, 256, 0, 8, 10),
        (248, 84, 240, 10, 8, 36),
        (232, 84, 224, 10, 16, 86),
        (184, 182, 232, 0, 24, 10),
        (160, 196, 112, 1, 96, 2),
    ]

    brackets_320 = Image.new("P", (320, 200), color=0)
    brackets_320.putpalette(pal)
    brk_pixels = brackets_320.load()

    for xs, ys, xd, yd, w, d in b_rects:
        for row in range(d):
            for col in range(w):
                pix = extra_pixels[xs + col, ys + row]
                if pix != 0:  # skip transparent mask 0
                    brk_pixels[xd + col, yd + row] = pix

    # Scale HUD brackets to 800x600 (mode 'P', nearest neighbor)
    brackets_800 = brackets_320.resize((CANVAS_W, CANVAS_H), Image.NEAREST)

    # IronWork rectangles from VGAPANEL.ASM:2160-2200
    iw_rects = [
        # LHS ironwork
        (160, 14, 0, 112, 40, 10),
        (200, 7, 40, 105, 40, 7),
        (240, 0, 80, 98, 80, 6),
        (160, 0, 0, 156, 24, 10),
        (256, 171, 32, 156, 32, 6),
        (272, 177, 48, 162, 16, 20),
        (312, 171, 88, 156, 8, 26),
        (160, 171, 56, 182, 8, 10),
        (192, 171, 88, 182, 24, 10),
        (224, 171, 96, 174, 24, 7),
        (200, 14, 40, 112, 40, 10),
        (240, 6, 80, 104, 80, 18),
        (160, 48, 0, 138, 160, 18),
        (288, 171, 64, 156, 24, 26),
        (168, 171, 64, 182, 24, 10),
        # RHS ironwork
        (280, 38, 280, 112, 40, 10),
        (240, 30, 240, 104, 40, 8),
        (160, 24, 160, 98, 80, 6),
        (296, 24, 296, 156, 24, 10),
        (288, 144, 256, 156, 32, 6),
        (288, 150, 256, 162, 16, 20),
        (256, 144, 224, 156, 8, 26),
        (208, 182, 256, 182, 8, 10),
        (160, 182, 208, 182, 24, 10),
        (224, 179, 200, 174, 24, 7),
        (240, 38, 240, 112, 40, 10),
        (160, 30, 160, 104, 80, 18),
        (160, 66, 160, 138, 160, 18),
        (264, 144, 232, 156, 24, 26),
        (184, 182, 232, 182, 24, 10),
        # Central ironwork
        (160, 193, 120, 174, 80, 2),
        (160, 196, 112, 183, 96, 2),
        (160, 199, 96, 156, 128, 1),
    ]

    # 2. Process each panel
    generated_bt2 = {}

    for panel_name in panels:
        p_dir = os.path.join(ORIG_EXTRACTED_DIR, panel_name)
        p_png = os.path.join(p_dir, f"{panel_name}.png")
        p_json = os.path.join(p_dir, f"{panel_name}.json")

        if not os.path.exists(p_png):
            print(f"Skipping {panel_name}: {p_png} not found")
            continue

        with open(p_json, "r", encoding="utf-8") as f:
            meta = json.load(f)

        src_img = Image.open(p_png)
        cur_pal = src_img.getpalette()

        orig_w = meta["width"]
        orig_h = meta["height"]
        orig_sy = meta["screen_y"]

        # Create target 800x600 panel directory
        out_panel_dir = os.path.join(OUT_800_DIR, panel_name)
        os.makedirs(out_panel_dir, exist_ok=True)

        if panel_name == "EXTRAPAN":
            # Build complete LookDown 320x200 composite (kneepads, reflected leg, stick, straps)
            left = extra_img.crop((0, 0, 160, 200))
            right = left.transpose(Image.FLIP_LEFT_RIGHT)
            ld320 = Image.new("P", (320, 200), color=0)
            ld320.putpalette(cur_pal)
            ld320.paste(left, (0, 0))
            ld320.paste(right, (160, 0))
            # Paste asymmetrical detail patches
            d1 = extra_img.crop((8, 49, 8 + 48, 49 + 77))
            ld320.paste(d1, (160, 0))
            d2 = extra_img.crop((8, 127, 8 + 32, 127 + 15))
            ld320.paste(d2, (144, 185))
            scaled_canvas = ld320.resize((CANVAS_W, CANVAS_H), Image.NEAREST)

        elif panel_name == "FRAMEPAN":
            # Build complete IronWork/Canopy Frame 320x200 composite
            iw320 = Image.new("P", (320, 200), color=0)
            iw320.putpalette(cur_pal)
            iw320.paste(src_img, (0, 122))
            iw_pix = iw320.load()
            for xs, ys, xd, yd, w, d in iw_rects:
                for row in range(d):
                    for col in range(w):
                        p = extra_pixels[xs + col, ys + row]
                        if p != 0:
                            iw_pix[xd + col, yd + row] = p
            scaled_canvas = iw320.resize((CANVAS_W, CANVAS_H), Image.NEAREST)
            # Extrude the canopy pillars at row 575 all the way to row 599
            fp_pix = scaled_canvas.load()
            for y in range(576, 600):
                for x in range(800):
                    fp_pix[x, y] = fp_pix[x, 575]

        elif panel_name == "NAVIGPAN":
            # Full 320x200 image -> scale directly to 800x600
            scaled_canvas = src_img.resize((CANVAS_W, CANVAS_H), Image.NEAREST)
            # Store scaled Master Arm lever guard sprites from EXTRAPAN
            # Day guard: EXTRAPAN (80, 49, 8, 8) -> NAVIGPAN (340, 282, 20, 24)
            # Night guard: EXTRAPAN (80, 57, 8, 8) -> NAVIGPAN (420, 282, 20, 24)
            day_guard = extra_img.crop((80, 49, 88, 57)).resize((20, 24), Image.NEAREST)
            night_guard = extra_img.crop((80, 57, 88, 65)).resize((20, 24), Image.NEAREST)
            d_pix = day_guard.load()
            n_pix = night_guard.load()
            c_pix = scaled_canvas.load()
            for r in range(24):
                for c in range(20):
                    c_pix[340 + c, 282 + r] = d_pix[c, r]
                    c_pix[420 + c, 282 + r] = n_pix[c, r]

        elif orig_h == 200 and orig_sy == 0:
            # Full 320x200 image -> scale directly to 800x600
            scaled_canvas = src_img.resize((CANVAS_W, CANVAS_H), Image.NEAREST)
        else:
            # Sub-panel (e.g. PILOTPAN 320x104 at y=96, PSIDEPAN 320x40 at y=160)
            scaled_w = int(round(orig_w * SCALE_X))
            scaled_h = int(round(orig_h * SCALE_Y))
            scaled_sy = int(round(orig_sy * SCALE_Y))

            scaled_part = src_img.resize((scaled_w, scaled_h), Image.NEAREST)
            scaled_canvas = Image.new("P", (CANVAS_W, CANVAS_H), color=0)
            scaled_canvas.putpalette(cur_pal)
            scaled_canvas.paste(scaled_part, (0, scaled_sy))

        # Special handling for PILOTPAN:
        # Pre-composite HUD brackets onto lines 0..287 of PILOTPAN
        if panel_name == "PILOTPAN":
            p_pix = scaled_canvas.load()
            b_pix = brackets_800.load()
            for y in range(288):
                for x in range(800):
                    bp = b_pix[x, y]
                    if bp != 0:
                        p_pix[x, y] = bp

        # Save 800x600 PNG
        out_png_path = os.path.join(out_panel_dir, f"{panel_name}.png")
        scaled_canvas.save(out_png_path)

        # Copy palette files
        for pal_ext in [".pal", "_palette.json"]:
            src_pal_f = os.path.join(p_dir, f"{panel_name}{pal_ext}")
            if os.path.exists(src_pal_f):
                shutil.copy2(src_pal_f, os.path.join(out_panel_dir, f"{panel_name}{pal_ext}"))

        # Scale sub-sprites and metadata
        scaled_subsprites = {}
        sub_manifest = {}
        src_manifest_f = os.path.join(p_dir, f"{panel_name}_subsprites", "manifest.json")

        if os.path.exists(src_manifest_f):
            with open(src_manifest_f, "r", encoding="utf-8") as f:
                orig_subs = json.load(f)

            out_subs_dir = os.path.join(out_panel_dir, f"{panel_name}_subsprites")
            os.makedirs(out_subs_dir, exist_ok=True)

            for s_name, s_data in orig_subs.items():
                s_rect_800 = scale_rect(s_data["rect"])
                s_dest_800 = scale_point(s_data.get("blit_dest", s_data["rect"][:2]))

                # For PILOTPAN: if s_rect is in local coordinates (y in 0..104),
                # adjust to screen coordinates in the 800x600 canvas (add 288)
                if panel_name == "PILOTPAN":
                    sx, sy, sw, sh = s_rect_800
                    sy_canvas = sy + 288
                    crop_800 = scaled_canvas.crop((sx, sy_canvas, sx + sw, sy_canvas + sh))
                    s_rect_800_canvas = [sx, sy_canvas, sw, sh]
                else:
                    sx, sy, sw, sh = s_rect_800
                    crop_800 = scaled_canvas.crop((sx, sy, sx + sw, sy + sh))
                    s_rect_800_canvas = s_rect_800

                crop_path = os.path.join(out_subs_dir, f"{s_name}.png")
                crop_800.save(crop_path)

                sub_info = {
                    "file": f"{s_name}.png",
                    "rect_canvas_800": s_rect_800_canvas,
                    "rect_local_800": s_rect_800,
                    "blit_dest_800": s_dest_800,
                    "description": s_data["description"]
                }
                scaled_subsprites[s_name] = sub_info
                sub_manifest[s_name] = sub_info

            with open(os.path.join(out_subs_dir, "manifest.json"), "w", encoding="utf-8") as f:
                json.dump(sub_manifest, f, indent=2)

        # Save scaled metadata JSON
        raw_bytes_800 = scaled_canvas.tobytes()
        import hashlib
        sha_800 = hashlib.sha256(raw_bytes_800).hexdigest()

        meta_800 = {
            "filename": f"{panel_name}.BT2",
            "width": CANVAS_W,
            "height": CANVAS_H,
            "file_size": len(raw_bytes_800),
            "sha256": sha_800,
            "screen_x": 0,
            "screen_y": 0,
            "subsprites_count": len(scaled_subsprites),
            "subsprites": scaled_subsprites
        }
        with open(os.path.join(out_panel_dir, f"{panel_name}.json"), "w", encoding="utf-8") as f:
            json.dump(meta_800, f, indent=2)

        # Generate 800x600 .BT2 binary file
        out_bt2_path = os.path.join(out_panel_dir, f"{panel_name}.BT2")
        with open(out_bt2_path, "wb") as f:
            f.write(raw_bytes_800)

        generated_bt2[panel_name] = out_bt2_path
        print(f"[OK] {panel_name:12} -> {out_bt2_path} ({len(raw_bytes_800)} bytes, {len(scaled_subsprites)} subsprites)")

    # 3. Copy new 800x600 .BT2 files to binary and source directories
    print("\nDeploying 800x600 .BT2 files to game folders...")
    for target_dir in [BIN_FLIGHT_DIR, SRC_FLIGHT_DIR]:
        if os.path.exists(target_dir):
            for pname, bt2_src in generated_bt2.items():
                dest_f = os.path.join(target_dir, f"{pname}.BT2")
                shutil.copy2(bt2_src, dest_f)
                print(f"  Copied {pname}.BT2 -> {dest_f}")

    print("\nScale and deployment to 800x600 completed successfully!")


if __name__ == "__main__":
    process_all()
